package calculadora;

import java.util.Scanner;


public class Calculadora {

    public static void main(String[] args) {
        int cont; 
       
  do{
        Scanner Operacion = new Scanner(System.in);
        
        int Select;
        calculator Calc=new calculator();
        Scanner obj2 = new Scanner(System.in);
        System.out.println("Menu:");       
        System.out.println("\n1= Suma\n2= Resta\n3= Producto\n4= Cociente\n5= Sin\n6= Cos\n7= Tan\n8= Raiz\n9= Potencia\n10= IVA");
     
        Select = Operacion.nextInt();      
        switch(Select){
            
            case 1:
                System.out.println("Ingrese un numero: ");
                float a1 = obj2.nextFloat();
                System.out.println("Ingrese otro numero: ");
                float b1 = obj2.nextFloat();
                System.out.println("Resultado= "+Calc.suma(a1, b1));
                break;
                
            case 2:
                System.out.println("Ingrese un numero: ");
                float a2 = obj2.nextFloat();
                System.out.println("Ingrese otro numero: ");
                float b2 = obj2.nextFloat();
                System.out.println("Resultado="+Calc.resta(a2, b2));
                break;
                
            case 3:
                System.out.println("Ingrese un numero: ");
                float a3 = obj2.nextFloat();
                System.out.println("Ingrese otro numero: ");
                float b3 = obj2.nextFloat();
                System.out.println("Resultado:"+Calc.multi(a3, b3));
                break;
                
            case 4:
                System.out.println("Ingrese un numero: ");
                float a4 = obj2.nextFloat();
                System.out.println("Ingrese otro numero: ");
                float b4 = obj2.nextFloat();
                System.out.println("Resultado:"+Calc.div(a4, b4));
                break;
                
            case 5:
                System.out.println("Ingrese un numero: ");
                float a5 = obj2.nextFloat();
                System.out.println("Resultado:"+(Calc.sin(a5)));
                break;
                
            case 6:
                System.out.println("Ingrese un numero: ");
                float a6 = obj2.nextFloat();
                System.out.println("Resultado:"+Calc.cos(a6)*(180/(Math.PI)));
                break;
                
            case 7:
                System.out.println("Ingrese un numero: ");
                float a7 = obj2.nextFloat();
                System.out.println("Resultado="+Calc.tan(a7));
                break;
                
            case 8:
                System.out.println("Ingrese un numero: ");
                float a8 = obj2.nextFloat();
                System.out.println("Ingrese el indice de la raiz: ");
                float ind = obj2.nextFloat();
                System.out.println("Resultado="+Calc.raiz(a8, ind));
                break;
                
            case 9:
                System.out.println("Ingrese un numero: ");
                float a9 = obj2.nextFloat();
                System.out.println("Ingrese el exponte:");
                float exp = obj2.nextFloat();
                System.out.println("Resultado:"+Calc.potencia(a9, exp));
                break;
                
            case 10:
                System.out.println("Ingrese el monto: ");
                float m = obj2.nextFloat();               
                System.out.println("Precio con IVA: " + "$" + Calc.iva(m));
                System.out.println("IVA: " + "$" + (Calc.iva(m)-m));
                break;                           
        }
        
        
        Scanner Cont = new Scanner(System.in);
        System.out.println("\nContinuar? \n1.Si\n2.No");
        cont=Cont.nextInt();
  }while(cont==1);
    }
    
}

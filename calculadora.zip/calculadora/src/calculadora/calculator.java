package calculadora;

public class calculator {
 

public double suma(double num1, double num2){
    double res= num1 + num2;
    return res;
}

public double resta(double num1, double num2){
    double res= num1 - num2;
    return res;
}

public double multi(double num1, double num2){
    double res= num1 * num2;
    return res;
}

public double div(double num1, double num2){
    /*if(num2==0){
        System.out.println("ERROR");
    }
    else{
    
   
    }*/
    double res= num1 / num2;
    return res;
}

public double raiz(double num1, double n){
        
    double res = Math.pow(num1,n);
    return res;
}
    
    
public double sin(double num1){
        
    double res = Math.sin(num1);
    return res;
}

public double cos(double num1){
        
    double cos = Math.cos(num1);
    return cos;
}

public double tan(double num1){
        
    double res = Math.tan(num1);
    return res;
}
    
public double potencia(double num1, double n){
        
    double potencia = Math.pow(num1,n);
    return potencia;
}
    
public double iva(double num1){
        
    double iva = (num1*0.19)+num1;
    return iva;
}
    
    
    
public static String op(String x, String y, String simb){
        
    Double res = 0.0;
    String Resp;
        
    if (simb.equals("+")){        
        res = Double.parseDouble(x)+Double.parseDouble(y);
    }
    
    
    else if(simb.equals("-")){
        res = Double.parseDouble(x)-Double.parseDouble(y);            
    }
    
    else if(simb.equals("*")){
        res = Double.parseDouble(x)*Double.parseDouble(y);            
    }
    
    else if(simb.equals("/")){
        res = Double.parseDouble(x)/Double.parseDouble(y);         
    }
    
    else if(simb.equals("^")){
        res = Math.pow(Double.parseDouble(x),Double.parseDouble(y));           
    }
        
    else if(simb.equals("sqrt")){
        res = Math.pow(Double.parseDouble(x),Double.parseDouble(y));      
    }
    
    
    Resp = res.toString();
    return Resp;
        
}
public static String opa(String x, String simb){
        
    Double res = 0.0;
    String Resp;
        
    if (simb.equals("Sin")){  
        res = Math.sin(Double.parseDouble(x));
    }
    
    
    else if (simb.equals("Cos")){    
        res = Math.cos(Double.parseDouble(x));
    }
    
    else if (simb.equals("Tan")){     
        res = Math.tan(Double.parseDouble(x));
    }
        
    Resp = res.toString();
    return Resp;
}


}